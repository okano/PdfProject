//
//  SimpleTouchPen02Tests.h
//  SimpleTouchPen02Tests
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface SimpleTouchPen02Tests : SenTestCase {
@private
    
}

@end
