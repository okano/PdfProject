//
//  SimpleTouchPen02Tests.m
//  SimpleTouchPen02Tests
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "SimpleTouchPen02Tests.h"


@implementation SimpleTouchPen02Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in SimpleTouchPen02Tests");
}

@end
