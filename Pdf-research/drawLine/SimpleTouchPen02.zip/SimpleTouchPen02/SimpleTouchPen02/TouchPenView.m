//
//  TouchPenView.m
//  SimpleTouchPen02
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TouchPenView.h"


@implementation TouchPenView
@synthesize lineToDraw;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        lineToDraw = [[NSMutableArray alloc] init];
    }
    return self;
}
- (id)init
{
    self = [super init];
    if (self) {
        lineToDraw = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)addLineInfoFrom:(CGPoint)p0 to:(CGPoint)p1
{
    NSLog(@"p0=%@, p1=%@", NSStringFromCGPoint(p0), NSStringFromCGPoint(p1));
    NSDictionary* tmpDict = [NSDictionary dictionaryWithObjectsAndKeys:
                             [NSNumber numberWithFloat:p0.x], LINE_POSITION_X0,
                             [NSNumber numberWithFloat:p0.y], LINE_POSITION_Y0,
                             [NSNumber numberWithFloat:p1.x], LINE_POSITION_X1,
                             [NSNumber numberWithFloat:p1.y], LINE_POSITION_Y1,
                             nil];
    NSLog(@"count of lineToDraw=%d", [lineToDraw count]);
    [lineToDraw addObject:tmpDict];
    NSLog(@"count of lineToDraw=%d", [lineToDraw count]);
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    if (! lineToDraw) {
        lineToDraw = [[NSMutableArray alloc] init];
    }
    
    // Drawing code
    NSLog(@"count of lineToDraw=%d", [lineToDraw count]);
    for (NSDictionary* lineInfo in lineToDraw) {
        CGContextRef context = UIGraphicsGetCurrentContext();
        if (! context) {
            NSLog(@"cannot get context.");
            return;
        }
        
        //Set line color.
        CGContextSetRGBStrokeColor(context, 0.0f, 0.0f, 1.0f, 1.0f);
        
        //Draw line.
        NSLog(@"line = (%f, %f) - (%f, %f)",[[lineInfo objectForKey:LINE_POSITION_X0] floatValue], [[lineInfo objectForKey:LINE_POSITION_Y0] floatValue],
              [[lineInfo objectForKey:LINE_POSITION_X1] floatValue], [[lineInfo objectForKey:LINE_POSITION_Y1] floatValue]);
        
        CGContextMoveToPoint(context, [[lineInfo objectForKey:LINE_POSITION_X0] floatValue], [[lineInfo objectForKey:LINE_POSITION_Y0] floatValue]);
        CGContextAddLineToPoint(context, [[lineInfo objectForKey:LINE_POSITION_X1] floatValue], [[lineInfo objectForKey:LINE_POSITION_Y1] floatValue]);
        CGContextStrokePath(context);
    }
    
    //[lineToDraw removeAllObjects];
}


- (void)dealloc
{
    [super dealloc];
}

@end
