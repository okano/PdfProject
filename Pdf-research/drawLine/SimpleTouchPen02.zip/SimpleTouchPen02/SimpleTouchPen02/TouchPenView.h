//
//  TouchPenView.h
//  SimpleTouchPen02
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface TouchPenView : UIView {
    NSMutableArray* lineToDraw;
}
@property (nonatomic, retain) NSMutableArray* lineToDraw;

- (void)addLineInfoFrom:(CGPoint)p0 to:(CGPoint)p1;
@end

#define LINE_POSITION_X0 @"x0"
#define LINE_POSITION_Y0 @"y0"
#define LINE_POSITION_X1 @"x1"
#define LINE_POSITION_Y1 @"y1"
