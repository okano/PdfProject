//
//  SimpleTouchPen02ViewController.h
//  SimpleTouchPen02
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SimpleTouchPen02ViewController : UIViewController {
    
}
- (IBAction)drawLineWithRandom;

@end
