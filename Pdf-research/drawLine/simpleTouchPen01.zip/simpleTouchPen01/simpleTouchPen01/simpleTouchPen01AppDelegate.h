//
//  simpleTouchPen01AppDelegate.h
//  simpleTouchPen01
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class simpleTouchPen01ViewController;

@interface simpleTouchPen01AppDelegate : NSObject <UIApplicationDelegate> {

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@property (nonatomic, retain) IBOutlet simpleTouchPen01ViewController *viewController;

@end
