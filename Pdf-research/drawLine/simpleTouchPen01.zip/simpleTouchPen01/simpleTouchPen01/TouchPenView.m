//
//  TouchPenView.m
//  simpleTouchPen01
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TouchPenView.h"


@implementation TouchPenView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    CGContextRef context = UIGraphicsGetCurrentContext();
    if (! context) {
        NSLog(@"cannot get context.");
        return;
    }
    
    //Set line color.
    CGContextSetRGBStrokeColor(context, 0.0f, 0.0f, 1.0f, 1.0f);
    //Draw line.
    CGContextMoveToPoint(context, 50.0f, 150.0f);
    CGContextAddLineToPoint(context, 100.0f, 200.0f);
    CGContextAddLineToPoint(context, 150.0f, 180.0f);
    CGContextStrokePath(context);
}


- (void)dealloc
{
    [super dealloc];
}

@end
