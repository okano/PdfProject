//
//  simpleTouchPen01Tests.m
//  simpleTouchPen01Tests
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "simpleTouchPen01Tests.h"


@implementation simpleTouchPen01Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in simpleTouchPen01Tests");
}

@end
