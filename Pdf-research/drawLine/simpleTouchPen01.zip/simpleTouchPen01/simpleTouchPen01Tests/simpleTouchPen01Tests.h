//
//  simpleTouchPen01Tests.h
//  simpleTouchPen01Tests
//
//  Created by okano on 11/03/16.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface simpleTouchPen01Tests : SenTestCase {
@private
    
}

@end
