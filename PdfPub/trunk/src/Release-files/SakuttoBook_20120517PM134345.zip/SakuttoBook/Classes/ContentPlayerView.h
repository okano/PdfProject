//
//  ContentPlayerView.h
//  SakuttoBook
//
//  Created by okano on 11/05/31.
//  Copyright 2010,2011 Katsuhiko Okano All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ContentPlayerView : UIViewController {
    
}

@end
