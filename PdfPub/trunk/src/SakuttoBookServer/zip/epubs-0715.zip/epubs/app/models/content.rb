class Content < ActiveRecord::Base
  attr_accessible :title, :author, :description, :product_id, :charge_type,
    :image, :file, :remove_image, :remove_file, :image_cache, :file_cache
  
  before_create {self.uuid = UUIDTools::UUID.random_create.to_s}
  
  # validation
  validates :title, presence: true
  validates :product_id, numericality: {only_integer: true, allow_blank: true}
  
  # CarrierWave
  mount_uploader :image, ImageUploader 
  mount_uploader :file, FileUploader 
  
  def before_destroy
    self.image.remove!
    self.file.remove!
  end
end
