class Content < ActiveRecord::Base
  attr_accessible :title, :author, :description, :product_id, :charge_type,
    :image, :file, :remove_image, :remove_file, :image_cache, :file_cache
  
  before_create {self.uuid = UUIDTools::UUID.random_create.to_s}
  
  # validation
  validates_presence_of :title
  
  # CarrierWave
  mount_uploader :image, ImageUploader 
  mount_uploader :file, FileUploader 
  
  def before_destroy
    image.remove!
    self.file.remove!
  end
end
