class CreateContents < ActiveRecord::Migration
  def change
    create_table :contents do |t|
      t.string :uuid         # UUID
      t.string :title        # タイトル
      t.string :author       # 著者名
      t.text :description    # 概要
      t.integer :product_id  # 課金用の商品ID
      t.integer :charge_type # 課金種別(0=無料, 2=有料(非消耗形))
      t.string :image        # コンテンツ実体のアップロード
      t.string :file         # 表紙画像のアップロード
      t.timestamps
    end
  end
end
