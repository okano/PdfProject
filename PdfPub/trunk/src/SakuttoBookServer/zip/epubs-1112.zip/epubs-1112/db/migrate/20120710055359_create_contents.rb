class CreateContents < ActiveRecord::Migration
  def change
    create_table :contents do |t|
      t.integer :parent_id                   # 親ID
      t.references :genre                    # ジャンルID
      t.integer :content_id, :unique => true # コンテンツID
      t.string :uuid                         # UUID
      t.string :title                        # タイトル
      t.string :author                       # 著者名
      t.text :description                    # 概要
      t.string :product_id                   # 課金用の商品ID
      t.integer :charge_type                 # 課金種別(0=無料, 2=有料(非消耗形))
      t.string :image                        # コンテンツ実体のアップロード
      t.string :file                         # 表紙画像のアップロード
      t.text :search_keyword                 # 検索用キーワード
      t.timestamps
    end
  end
end
