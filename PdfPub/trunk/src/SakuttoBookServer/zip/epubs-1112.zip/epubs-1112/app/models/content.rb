class Content < ActiveRecord::Base
  attr_accessible :parent_id, :genre_id, :content_id, :title, :author, :description, :product_id, :charge_type,
    :image, :file, :remove_image, :remove_file, :image_cache, :file_cache, :search_keyword
  
  before_create {self.uuid = UUIDTools::UUID.random_create.to_s}
  
  belongs_to :genre
  has_many :children, :class_name => 'Content', :foreign_key => :parent_id
  belongs_to :parent, :class_name => 'Content', :foreign_key => :parent_id
  
  # validation
  validates :content_id, uniqueness: true, numericality: {greater_than: 0}
  validates :title, presence: true
  validates :product_id, format: {with: /^[a-zA-Z0-9]+$/, allow_blank: true}
  
  # CarrierWave
  mount_uploader :image, ImageUploader 
  mount_uploader :file, FileUploader 
  
#  # overridden
#  def to_param
#    content_id
#  end
  
  def before_destroy
    self.image.remove!
    self.file.remove!
  end
  
  # cid: コンテンツID(カンマ区切り) 
#  def self.children_by_cid(cid)
#    cids = []
#    content_ids = cid.split(',').map(&:strip)
#    content_ids.each do |content_id|
##      cids << content_id
##      content = where(content_id: content_id).first
##      
##      cids <<  content.children.pluck(:content_id)
#    end
#    cids
#  end
  
#  def self.all_chidren_by_cid(cid)
#    content = where(content_id: cid).first
#    return [] if content.blank?
#    
#    content_ids = content.children.pluck(:content_id)
#  end
end
