# coding: utf-8
class ContentsController < ApplicationController
  http_basic_authenticate_with :realm => "aaa", :name => "user", :password => "password"
  
  def index
    @contents = Content.order('created_at DESC')
    @updated = Content.maximum(:updated_at).in_time_zone(Time.zone).iso8601
    #@updated = @contents.pluck(:updated_at).max.to_datetime.iso8601
    
    respond_to do |format|
      format.opds #{ headers['Content-Type'] = 'application/atom+xml;type=feed' }
      format.csv do
        header = "#Content-ID(1-start), Product-ID(String with iTunesConnect), Purchase-type(0=FREE 1=Consumable(shoumou-gata) 2=Non-Consumable(hi-shoumou-gata))"
        lines = @contents.map{|c| "#{c.content_id},#{c.product_id},#{c.charge_type}"}
        lines.unshift(header)
        render :text => lines.join("\n"), :content_type => 'text/plain'
      end
      format.html
    end
  end
  
  def recent
    @contents = Content.order('created_at DESC')
    @updated = Content.maximum(:updated_at).in_time_zone(Time.zone).iso8601
    #@updated = @contents.pluck(:updated_at).max.to_datetime.iso8601
    
    respond_to {|format| format.opds}
  end
  
  # 検索
  def search
    
    @contents = Content.scoped
    
    # genre指定(スラッグのカンマ区切り)
    if params[:genre].present?
      genre_ids = Genre.where(:slug => params[:genre].split(',').map(&:strip)).pluck(:id)
      @contents = @contents.where(genre_id: genre_ids)
    end
    
    # コンテンツID(カンマ区切り) 指定
    if params[:cid].present?
      content_ids = params[:cid].split(',').map(&:strip).map(&:to_i)
      
      # 子コンテンツIDも取得する
      children_content_ids = []
      content_ids.each do |content_id|
        content = Content.find_by_content_id(content_id)
        next if content.blank?
        #children_content_ids << content_id.to_i
        children_content_ids << content.children.pluck(:content_id)
      end

      children_content_ids = children_content_ids.flatten.uniq

      # 孫コンテンツIDも取得する
      children_content_ids2 = []
      children_content_ids.each do |content_id|
        content = Content.find_by_content_id(content_id)
        next if content.blank?
        #children_content_ids2 << content_id.to_i
        children_content_ids2 << content.children.pluck(:content_id)
      end
      children_content_ids2 = children_content_ids2.flatten.uniq
  
      all_content_ids = content_ids + children_content_ids + children_content_ids2
      all_content_ids = all_content_ids.uniq

      @contents = @contents.where(content_id: all_content_ids)
    end
    
    # 並び順 指定
    if params[:order].present?
      @contents = @contents.order('author')          if params[:order] == 'author'
      @contents = @contents.order('updated_at DESC') if params[:order] == 'new'
    end
    
    # 検索キーワード
    if params[:q].present?
      @contents = @contents.where('title LIKE :q OR author LIKE :q OR search_keyword LIKE :q', :q => "%#{params[:q]}%")
    end
    
    # 著者名
    if params[:author].present?
      @contents = @contents.where(author: params[:author])
    end
    
    # タイトル名
    if params[:title].present?
      @contents = @contents.where(title: params[:title])
    end
    
    @contents = @contents.order('created_at DESC')
    @updated = Content.maximum(:updated_at).in_time_zone(Time.zone).iso8601
    respond_to {|format| format.opds}
  end
end
