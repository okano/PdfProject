class ContentsController < ApplicationController
  http_basic_authenticate_with :name => "user", :password => "password"
  
  def index
    @contents = Content.order('created_at DESC')
    respond_to do |format|
      format.opds
      format.csv do
        header = "#Content-ID(1-start), Product-ID(String with iTunesConnect), Purchase-type(0=FREE 1=Consumable(shoumou-gata) 2=Non-Consumable(hi-shoumou-gata))"
        lines = @contents.map{|c| "#{c.id}, #{c.product_id}, #{c.charge_type}"}
        lines.unshift(header)
        render :text => lines.join("\n"), :content_type => 'text/plain'
      end
    end
  end
  
  def show
    @content = Content.find(params[:id])
    respond_to {|format| format.opds}
  end
  
  def recent
    @contents = Content.order('created_at DESC')
    respond_to {|format| format.opds}
  end
  
#  def csv
#    @contents = Content.order('created_at DESC')
#    text = []
#    text << "#Content-ID(1-start), Product-ID(String with iTunesConnect), Purchase-type(0=FREE 1=Consumable(shoumou-gata) 2=Non-Consumable(hi-shoumou-gata))"
#    @contents.each do |c|
#      text << "#{c.id}, #{c.product_id}, #{c.charge_type}"
#    end
#    render :text => text.join("\n")
#  end
end
