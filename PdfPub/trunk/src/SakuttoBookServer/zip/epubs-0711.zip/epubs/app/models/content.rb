class Content < ActiveRecord::Base
  attr_accessible :title, :author, :description, :product_id, :charge_type, :image_url, :file_url
  
  before_create {self.uuid = UUIDTools::UUID.random_create.to_s}
  
  # validation
  validates_presence_of :title
end
