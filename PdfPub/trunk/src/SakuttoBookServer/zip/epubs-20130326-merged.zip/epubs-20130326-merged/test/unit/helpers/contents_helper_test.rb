require 'test_helper'

class ContentsHelperTest < ActionView::TestCase
end
