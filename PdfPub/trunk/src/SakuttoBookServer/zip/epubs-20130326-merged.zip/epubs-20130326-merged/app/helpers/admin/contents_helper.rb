# coding: utf-8
module Admin::ContentsHelper
  # 一覧表示のソート用リンクを生成する
  def sort_link(column)
    direction = (column.to_s == params[:sort] && params[:direction] == 'asc') ? 'desc' : 'asc'
    sort_mark   = direction == 'asc' ? '▼' : '▲'
    sort_params = {:sort => column, :direction => direction}

    link_to sort_mark, sort_params
  end
end
