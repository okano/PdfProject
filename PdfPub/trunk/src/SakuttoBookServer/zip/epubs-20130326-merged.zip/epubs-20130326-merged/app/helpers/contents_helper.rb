module ContentsHelper

  def content_price(tier)
    TIER_HASH[tier]
  end
end
