class Genre < ActiveRecord::Base
  attr_accessible :name, :slug
  
  has_many :content, :dependent => :nullify
  
  validates :name, presence: true
  validates :slug, presence: true, format: {with: /^[a-zA-Z0-9_-]+$/}
end
