# coding: utf-8
class Admin::GenresController < ApplicationController
  layout 'admin'
  http_basic_authenticate_with :realm => "admin", :name => "admin", :password => "password"
  
  def index
    @genres = Genre.page(params[:page])
    @genres = @genres.where("name LIKE ? OR slug LIKE ?", "%#{params[:keyword]}%", "%#{params[:keyword]}%") if params[:keyword]
    
    if params[:sort]
      @genres = @genres.order(params[:sort] + ' ' + params[:direction].upcase) if params[:sort]
    else
      #@genres = @genres.order('created_at DESC')
    end
  end

  def show
    @genre = Genre.find(params[:id])
  end

  def new
    @genre = Genre.new
  end
  
  def create
    @genre = Genre.new params[:genre]
    
    if @genre.save
      redirect_to admin_genres_path, notice: 'ジャンルを作成しました。'
    else
      render :new
    end
  end
  
  def edit
    @genre = Genre.find(params[:id])
  end
  
  def update
    @genre = Genre.find(params[:id])

    if @genre.update_attributes(params[:genre])
      redirect_to [:admin, @genre], notice: 'ジャンルを編集しました。'
    else
      render action: "edit"
    end

  end
  
  def destroy
    @genre = Genre.find(params[:id])
    @genre.destroy

    redirect_to admin_genres_path, notice: 'ジャンルを削除しました。'
  end
end

