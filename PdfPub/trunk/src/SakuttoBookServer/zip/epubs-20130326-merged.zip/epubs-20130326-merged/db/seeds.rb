# coding: utf-8

# # This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rake db:seed (or created alongside the db with db:setup).
#
# Examples:
#
#   cities = City.create([{ name: 'Chicago' }, { name: 'Copenhagen' }])
#   Mayor.create(name: 'Emanuel', city: cities.first)
#

100.times do |i|
  Content.create! do |c|
    c.content_id  = i+1
    c.title       = "titile_#{i+1}"
    c.author      = "author_#{i+1}"
    c.description = "aaaaa\nbbbbbb\ncccccc"
    c.product_id  = [*1..10].sample
    c.charge_type = [0,2].sample
    c.created_at  = i.second.since
    c.updated_at  = i.second.since
  end
end