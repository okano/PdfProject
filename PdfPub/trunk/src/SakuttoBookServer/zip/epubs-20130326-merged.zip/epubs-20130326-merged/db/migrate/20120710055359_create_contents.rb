class CreateContents < ActiveRecord::Migration
  def change
    create_table :contents do |t|
      t.integer :parent_id                   # 親ID
      t.references :genre                    # ジャンルID
      t.integer :content_id, :unique => true # コンテンツID
      t.string :uuid                         # UUID
      t.string :title                        # タイトル
      t.string :author                       # 著者名
      t.text :description                    # 概要
      t.string :product_id                   # 課金用の商品ID
      t.integer :charge_type                 # 課金種別(0=無料, 2=有料(非消耗形))
      t.integer :tier                        # 価格 Tier0からTier87まで
      t.string :image                        # 表紙画像のアップロード
      t.string :image1                       # 表紙画像のアップロード
      t.string :image2                       # 表紙画像のアップロード
      t.string :image3                       # 表紙画像のアップロード
      t.string :image4                       # 表紙画像のアップロード
      t.string :sample_file                  # プレビュー用ファイル
      t.string :file                         # 本体ファイル (zip, cbz) 
      t.text :search_keyword                 # 検索用キーワード
      t.string :related_content_ids          # 関連コンテンツID(カンマ区切り)
      t.timestamps
    end
  end
end
