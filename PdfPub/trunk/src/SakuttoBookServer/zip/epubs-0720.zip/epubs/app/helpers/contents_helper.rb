module ContentsHelper
end
