# coding: utf-8
class Admin::ContentsController < ApplicationController
  layout 'admin'
  http_basic_authenticate_with :name => "admin", :password => "password"
  
  def index
    @contents = Content.page(params[:page])
    @contents = @contents.where("title LIKE ?", "%#{params[:keyword]}%") if params[:keyword]
    
    if params[:sort]
      @contents = @contents.order(params[:sort] + ' ' + params[:direction].upcase) if params[:sort]
    else
      @contents = @contents.order('created_at DESC')
    end
  end

  def show
    @content = Content.find(params[:id])
  end

  def new
    @content = Content.new
    @content.content_id = Content.maximum(:content_id).succ
  end
  
  def create
    @content = Content.new params[:content]
    
    if @content.save
      redirect_to admin_contents_path, notice: 'コンテンツを作成しました。'
    else
      render :new
    end
  end
  
  def edit
    @content = Content.find(params[:id])
  end
  
  def update
    @content = Content.find(params[:id])

    if @content.update_attributes(params[:content])
      redirect_to [:admin, @content], notice: 'コンテンツを編集しました。'
    else
      render action: "edit"
    end

  end
  
  def destroy
    @content = Content.find(params[:id])
    @content.destroy

    redirect_to admin_contents_path, notice: 'コンテンツを削除しました。'
  end
end
