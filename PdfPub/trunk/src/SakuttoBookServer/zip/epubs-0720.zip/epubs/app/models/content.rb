class Content < ActiveRecord::Base
  attr_accessible :content_id, :title, :author, :description, :product_id, :charge_type,
    :image, :file, :remove_image, :remove_file, :image_cache, :file_cache
  
  before_create {self.uuid = UUIDTools::UUID.random_create.to_s}
  
  # validation
  validates :content_id, uniqueness: true, numericality: {greater_than: 0}
  validates :title, presence: true
  validates :product_id, format: {with: /^[a-zA-Z0-9]+$/, allow_blank: true}
  
  # CarrierWave
  mount_uploader :image, ImageUploader 
  mount_uploader :file, FileUploader 
  
#  # overridden
#  def to_param
#    content_id
#  end
  
  def before_destroy
    self.image.remove!
    self.file.remove!
  end
end
