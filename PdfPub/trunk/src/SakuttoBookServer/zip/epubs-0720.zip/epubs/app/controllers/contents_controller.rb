class ContentsController < ApplicationController
  http_basic_authenticate_with :name => "user", :password => "password"
  
  def index
    @contents = Content.order('created_at DESC')
    @updated = Content.maximum(:updated_at).in_time_zone(Time.zone).iso8601
    #@updated = @contents.pluck(:updated_at).max.to_datetime.iso8601
    
    respond_to do |format|
      format.opds #{ headers['Content-Type'] = 'application/atom+xml;type=feed' }
      format.csv do
        header = "#Content-ID(1-start), Product-ID(String with iTunesConnect), Purchase-type(0=FREE 1=Consumable(shoumou-gata) 2=Non-Consumable(hi-shoumou-gata))"
        lines = @contents.map{|c| "#{c.content_id},#{c.product_id},#{c.charge_type}"}
        lines.unshift(header)
        render :text => lines.join("\n"), :content_type => 'text/plain'
      end
      format.html
    end
  end
  
  def recent
    @contents = Content.order('created_at DESC')
    @updated = Content.maximum(:updated_at).in_time_zone(Time.zone).iso8601
    #@updated = @contents.pluck(:updated_at).max.to_datetime.iso8601
    
    respond_to {|format| format.opds}
  end
end
