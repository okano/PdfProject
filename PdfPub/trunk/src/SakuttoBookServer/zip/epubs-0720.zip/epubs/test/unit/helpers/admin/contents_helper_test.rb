require 'test_helper'

class Admin::ContentsHelperTest < ActionView::TestCase
end
